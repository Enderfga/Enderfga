### 依赖
- 安装 OpenAI gym 和 <a href="https://github.com/erlerobot/gym-gazebo">gym_gazebo</a> :
```
sudo pip install gym
sudo apt-get install python-skimage
sudo pip install h5py
pip install tensorflow-gpu
sudo pip install keras

cd ~
git clone https://github.com/erlerobot/gym-gazebo
cd gym-gazebo
sudo pip install -e .
```
- Ardrone simulation: 
```
git clone https://github.com/YugAjmera/quadrotor_ros
```

```
catkin_make
```


### Q-learning

```shell
roslaunch rl_mav_ros world.launch
roslaunch rl_mav_ros start_qlearning.launch
```


### Sarsa
```shell
roslaunch rl_mav_ros world.launch
roslaunch rl_mav_ros start_sarsa.launch
```


### Expected-Sarsa
```shell
roslaunch rl_mav_ros world.launch
roslaunch rl_mav_ros start_expected_sarsa.launch
```

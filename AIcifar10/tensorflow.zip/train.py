import tensorflow as tf
from model import *
from utils import *
import os


os.environ['CUDA_VISIBLE_DECIVES'] = "0"

FLAG = tf.app.flags.FLAGS

tf.app.flags.DEFINE_string('model_save_path', './model', """Where to save the final network.""")
tf.app.flags.DEFINE_integer('total_epochs', 6, """Number of epoches.""")
tf.app.flags.DEFINE_integer('batch_size', 100, """Size of each batch.""")
tf.app.flags.DEFINE_float('init_learning_rate', 1e-3, """Learning rate.""")
tf.app.flags.DEFINE_string('learning_rate_decay_type', 'exponential', """Type of learning rate decay.""")
tf.app.flags.DEFINE_integer('decay_steps', 100, """Total number of steps of learning rate decay.""")
tf.app.flags.DEFINE_float('decay_rate', 0.99, """Global step of the decayed learning rate.""")
tf.app.flags.DEFINE_string('normalization_type', 'BN', """Type of normalization.""")


# 先构建模型训练的整个图，用占位符代替数据
graph = tf.Graph()

with graph.as_default(): 
    # 构建占位符
    images_placeholder = tf.placeholder(tf.float32, shape=(None, 32, 32, 3), name='img')
    labels_placeholder = tf.placeholder(tf.float32, shape=(None, 10), name='label')
    train_flag = tf.placeholder(tf.bool, None)


    def enhance():  return data_enhance(images_placeholder)
    def mix_up():   return mixup(images_placeholder, labels_placeholder, FLAG.batch_size)
    def default_1():    return images_placeholder
    def default_2():    return images_placeholder, labels_placeholder
    
    # 条件函数实现对训练数据的增强，不增强测试数据
    images_placeholder = tf.cond(train_flag, enhance, default_1)
    # 条件函数实现 mixup
    images_placeholder, labels_placeholder = tf.cond(train_flag, mix_up, default_2)


    global_step = tf.Variable(0, trainable=False)

    # 学习率
    # 指数衰减
    if FLAG.learning_rate_decay_type == 'exponential':
        configured_lr = tf.train.exponential_decay(FLAG.init_learning_rate, global_step, FLAG.decay_steps, FLAG.decay_rate,
                                                        staircase=False, name='exponential_decay_learning_rate')
    # 固定学习率
    elif FLAG.learning_rate_decay_type == 'fixed':
        configured_lr = tf.constant(FLAG.init_learning_rate, name='fixed_learning_rate')
        
    
    [C1, C2, C3, C4, C5, output] = ResNet(images_placeholder, 
                                        norm_type=FLAG.normalization_type, 
                                        train_flag=train_flag, 
                                        stage5=True)
    
    correct_prediction = tf.equal(tf.argmax(output,1),tf.argmax(labels_placeholder,1))
    accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))

    # 损失函数
    cross_entrophy = tf.nn.softmax_cross_entropy_with_logits_v2(logits=output, labels=labels_placeholder, name='train_xentrophy')
    cross_loss = tf.reduce_mean(cross_entrophy, name='train_xentrophy_mean')
    tf.add_to_collection('losses', cross_loss)
    loss = tf.add_n(tf.get_collection('losses'))



    # 优化
    optimizer = tf.train.AdamOptimizer(configured_lr)
    
    '''
    # 梯度裁剪: 取消该程序段的注释, 并将“train_op = optimizer.minimize(loss, global_step=global_step)”注释, 即可实现梯度裁剪
    grads = optimizer.compute_gradients(loss)
    for i, (g, v) in enumerate(grads):
       if g is not None:
           grads[i] = (tf.clip_by_norm(g, 5), v)
    train_op = optimizer.apply_gradients(grads, global_step=global_step)
    '''
    
    train_op = optimizer.minimize(loss, global_step=global_step)

    saver = tf.train.Saver()

    
    with tf.Session() as sess:
        # 加载数据集
        data = DataLoader()

        # 初始化变量
        sess.run(tf.initialize_all_variables())

        # 加载训练集数据，用于计算训练集准确率
        train_data_all = data.all_train_data()
        x_train_all = np.array(train_data_all[0])/255.0
        y_train_all = np.array(train_data_all[1])

        # 加载测试集数据
        test_data = data.all_test_data()
        x_test_all = np.array(test_data[0])/255.0

        y_test_all = np.array(test_data[1])

        #加载开发集数据
        dev_data=data.all_dev_data()
        x_dev_all = np.array(dev_data[0])/255.0
        y_dev_all = np.array(dev_data[1])

        total_loss=[]
        total_acc=[]
        
        for epoch in range(FLAG.total_epochs):
            total_batch = len(data.data_label_train) // FLAG.batch_size
            for step in range(1, total_batch+1):
                train_accuracy = 0                
                test_accuracy = 0
                
                x_train, y_train = data.next_train_data(FLAG.batch_size)

                # 图像 rescale 到 [0, 1]，加速收敛
                x_train = np.array(x_train)/255.0
                y_train = np.array(y_train)

                _, step_loss, step_accuracy = sess.run([train_op, loss, accuracy], feed_dict={images_placeholder: x_train, labels_placeholder: y_train, train_flag: True})
 
                if step % 20 == 0:    # checkpoint
                    save_path = saver.save(sess, './checkpoints/model_' + str(epoch) + '_' + str(step) + '.ckpt')
                    
                    # 训练集准确率, 分批次测试可以更快完成计算
                    for j in range(60):
                        train_accuracy_ = accuracy.eval(feed_dict={images_placeholder: x_train_all[j*100:(j+1)*100], labels_placeholder: y_train_all[j*100:(j+1)*100], train_flag:False})
                        train_accuracy += train_accuracy_
                    train_accuracy = train_accuracy / 60

                    # 测试集准确率
                    for j in range(20):
                        test_accuracy_ = accuracy.eval(feed_dict={images_placeholder: x_test_all[j*100:(j+1)*100], labels_placeholder: y_test_all[j*100:(j+1)*100], train_flag:False})
                        test_accuracy += test_accuracy_
                    test_accuracy = test_accuracy / 20

                    dev_accuracy = accuracy.eval(feed_dict={images_placeholder: x_dev_all, labels_placeholder: y_dev_all, train_flag:False})
                
                    global_val=sess.run(global_step)
                    lr_val=sess.run(configured_lr)

                    print("Epoch %d step %d, training accuracy: %g, testing accuracy: %g, dev accuracy: %g, step accuracy: %g, step loss: %g, lr: %g" % (epoch, global_val, train_accuracy, test_accuracy, dev_accuracy, step_accuracy, step_loss, lr_val))

        final_test_data = data.all_final_test_data()
        x_final_test = np.array(final_test_data[0]) / 255.0
        y_final_test = np.array(final_test_data[1])

        # 准确率
        final_accuracy = 0
        for j in range(100):
            final_accuracy_ = accuracy.eval(feed_dict={images_placeholder: x_final_test[j*100:(j+1)*100], labels_placeholder: y_final_test[j*100:(j+1)*100], train_flag:False})
            final_accuracy += final_accuracy_
        final_accuracy = final_accuracy / 100
        print("Accuracy on the origin test data is: %g" % final_accuracy)

        #保存模型
        save_path = saver.save(sess,"./model/ResNet34_GN.ckpt")
        print("save model:{0} Finished".format(save_path))



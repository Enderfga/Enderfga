import tensorflow as tf
import numpy as np
import random
from tensorflow.keras.datasets import cifar10


# 随机旋转，裁切、亮度变化、对比度变化
def data_enhance(x):
    x = tf.image.random_flip_left_right(x)
    x = tf.image.random_hue(x, max_delta=0.2)
    x = tf.image.random_brightness(x, max_delta=0.7)
    result = tf.image.random_contrast(x, lower=0.2, upper=1.8)
    return result

# mixup
def mixup(batch_x, batch_y, batch_size, alpha=1.0):
    if alpha > 0:
        lam = np.random.beta(alpha, alpha)
    else:
        lam = 1
    index = tf.random_shuffle(batch_size)
    mixed_batch_x = lam * batch_x + (1 - lam) * batch_x[index, :]

    batch_y_ = lam * batch_y + (1 - lam) * batch_y[index]
    return mixed_batch_x, batch_y_


# 在线载入cifar10数据集
def load_cifar10_batch_online():
    (x_Train, y_Train), (x_Test, y_Test) = cifar10.load_data()
    return x_Train, y_Train, x_Test, y_Test

# cifar10数据集读取器
class DataLoader():
    def __init__(self, cifar_folder=None, onehot=True):
        self.cifar_folder = cifar_folder
        self.onehot = onehot
        self.data_label_train = []
        self.data_label_test = []
        self.data_label_dev = []
        self.data_label_final_test = None
        self.batch_index = 0

        if cifar_folder==None:  # 在线获得cifar10数据
            x_train, y_train, x_test, y_test = load_cifar10_batch_online()

            self.data_label_final_test = list(zip(x_test, y_test))
            data_label_train = list(zip(x_train, y_train))
            data_label_train = sorted(data_label_train, key=lambda pair:pair[1])

            for i in range(10):
                index = random.sample(range(i*5000, (i+1)*5000), 1000)  # 随机抽取1000个样本
                tmp = []
                for j in index:
                    tmp.append(data_label_train[j])
                tmp_train, tmp_test, tmp_dev = np.split(tmp, [600, 800])
                self.data_label_train.extend(tmp_train)
                self.data_label_test.extend(tmp_test)
                self.data_label_dev.extend(tmp_dev)
            
            np.random.shuffle(self.data_label_train)


    # 独热编码
    def _decode(self, data_label, onehot):
        rdata = list()
        rlabel = list()
        if onehot:
            for d, l in data_label:
                rdata.append(d)
                hot = np.zeros(10)
                hot[int(l)] = 1
                rlabel.append(hot)
        else:
            for d, l in data_label:
                rdata.append(d)
                rlabel.append(int(l))
        return rdata, rlabel

    # 按照批次读取训练集数据
    def next_train_data(self, batch_size=100):
        if self.batch_index < len(self.data_label_train) // batch_size:
            data_label = self.data_label_train[self.batch_index * batch_size:(self.batch_index + 1) * batch_size]
            self.batch_index += 1
            np.random.shuffle(data_label)
            return self._decode(data_label, self.onehot)
        else:
            self.batch_index = 0
            np.random.shuffle(self.data_label_train)
            data_label = self.data_label_train[self.batch_index * batch_size:(self.batch_index + 1) * batch_size]
            self.batch_index += 1
            return self._decode(data_label, self.onehot)

    # 读取所有训练集数据
    def all_train_data(self):
        np.random.shuffle(self.data_label_train)
        data_label = self.data_label_train
        return self._decode(data_label, self.onehot)


    # 按照批次读取测试集数据
    def next_test_data(self, batch_size=100):
        np.random.shuffle(self.data_label_test)
        data_label = self.data_label_test[0:batch_size]
        return self._decode(data_label, self.onehot)

    # 读取所有测试集数据
    def all_test_data(self):
        np.random.shuffle(self.data_label_test)
        data_label = self.data_label_test
        return self._decode(data_label, self.onehot)

    # 读取所有验证集数据
    def all_dev_data(self):
        np.random.shuffle(self.data_label_dev)
        data_label = self.data_label_dev
        return self._decode(data_label, self.onehot)
        
    # 读取原数据集的测试集，用于做最终的准确率测试
    def all_final_test_data(self):
        np.random.shuffle(self.data_label_final_test)
        return self._decode(self.data_label_final_test, self.onehot)
import tensorflow as tf
import numpy as np


# 下面三个函数完成了卷积层的构建
def weight_variable(shape, name="weights"):
    weights = tf.get_variable(name, shape, initializer=tf.contrib.keras.initializers.he_normal())
    #加入l2正则化
    #regular=tf.multiply(tf.nn.l2_loss(weights), 0.005, name='regular')
    #tf.add_to_collection('losses',regular)    
    return weights

def bias_variable(shape, name="biases"):
    biases = tf.get_variable(name, shape, initializer=tf.constant_initializer(0.0))
    return biases

def conv_layer(x, w, b, name, strides, padding = 'SAME'):
    """
    卷积层
    Input:
        x:被卷积的张量
        w:权重(卷积核)矩阵的形状
        b:偏置矩阵的形状
    Output:
        卷积且加入偏置后的张量
    """
    w = weight_variable(w, name=name+'w')
    b = bias_variable(b, name=name+'b')
    conv_and_biased = tf.nn.conv2d(x, w, strides=strides, padding=padding, name=name) + b
    return conv_and_biased

def batch_norm(x, scope, is_training):
    """
    批次正则化
    """
    with tf.variable_scope(scope):
        beta = tf.Variable(tf.constant(0.0, shape=[x.shape[-1]]), name='beta_bn', trainable=True)
        gamma = tf.Variable(tf.constant(1.0, shape=[x.shape[-1]]), name='gamma_bn', trainable=True)

        axes = list(np.arange(len(x.shape)-1))
        batch_mean, batch_var = tf.nn.moments(x, axes, name='moments_bn')

        ema = tf.train.ExponentialMovingAverage(decay=0.5)
        
        def mean_var_with_update():
            ema_apply_op = ema.apply([batch_mean, batch_var])
            with tf.control_dependencies([ema_apply_op]):
                return tf.identity(batch_mean), tf.identity(batch_var)

        # 训练则用mean_var_with_update这个函数计算该批次的均值与方差；测试则直接用ema
        mean, var = tf.cond(is_training, mean_var_with_update, lambda:(ema.average(batch_mean), ema.average(batch_var)))

        normed = tf.nn.batch_normalization(x, mean, var, beta, gamma, 1e-3, name='bn')

    return normed

def norm(x, scope, norm_type, is_training):
    """
    正则化
    """
    if norm_type=='BN':
        return batch_norm(x, scope, is_training)
    else:
        return x

def maxpooling(x, kernal_size, strides, name):  # 最大池化，前面的是核大小，一般为[1, 2, 2, 1]，后面的strides指的是步长，如[1, 2, 2, 1]。
    return tf.nn.max_pool(x, ksize=kernal_size, strides=strides, padding='SAME', name = name)

def avg_pool(input_feats, k):
    ksize = [1, k, k, 1]
    strides = [1, k, k, 1]
    padding = 'VALID'
    output = tf.nn.avg_pool(input_feats, ksize, strides, padding)  # 平均池化
    return output

def conv_block(input_tensor, kernel_size, bn_filters, stage, block, norm_type, train_flag, stride2=False):
    """
    Residual convolutional block, 一个卷积模块,包含2-3个卷积层, 并且有残差连接
    """
    bn_filter1, bn_filter2 = bn_filters
    conv_name_base = 'res' + str(stage) + block + '_branch'
    bn_name_base = 'bn' + str(stage) + block + '_branch'
    _, _, _, input_layers = input_tensor.get_shape().as_list()
    if stride2 == False:
        stride_for_first_conv = [1, 1, 1, 1]
    else:
        stride_for_first_conv = [1, 2, 2, 1]

    x = conv_layer(input_tensor, [3, 3, input_layers, bn_filter1], [bn_filter1], strides=stride_for_first_conv, padding='SAME', name=conv_name_base + '2a')
    x = norm(x, scope=bn_name_base + '2a', norm_type=norm_type, is_training=train_flag)
    
    x = conv_layer(x, [3, 3, bn_filter1, bn_filter2], [bn_filter2], strides=[1, 1, 1, 1], padding='SAME', name=conv_name_base + '2b')
    x = norm(x, scope=bn_name_base + '2b', norm_type=norm_type, is_training=train_flag)
    
    shortcut = conv_layer(input_tensor, [3, 3, input_layers, bn_filter2], [bn_filter2], strides=stride_for_first_conv, padding='SAME', name=conv_name_base + '1')
    shortcut = norm(shortcut, scope=bn_name_base + '1', norm_type=norm_type, is_training=train_flag)

    x = tf.add(x, shortcut)

    x = tf.nn.relu(x, name='res'+str(stage)+block+'_out') 
    
    return x

def identity_block(input_tensor, kernel_size, bn_filters, stage, block, norm_type, train_flag):
    """
    Identity convolutional block
    """
    bn_filter1, bn_filter2 = bn_filters
    conv_name_base = 'res' + str(stage) + block + '_branch'
    bn_name_base = 'bn' + str(stage) + block + '_branch'
    _, _, _, input_layers = input_tensor.get_shape().as_list()

    x = conv_layer(input_tensor, [3, 3, input_layers, bn_filter1], [bn_filter1], strides=[1, 1, 1, 1], padding='SAME', name=conv_name_base + '2a')
    x = norm(x, scope=bn_name_base + '2a', norm_type=norm_type, is_training=train_flag)
    
    x = conv_layer(x, [3, 3, bn_filter1, bn_filter2], [bn_filter2], strides=[1, 1, 1, 1], padding='SAME', name=conv_name_base + '2b')
    x = norm(x, scope=bn_name_base + '2b', norm_type=norm_type, is_training=train_flag)
    
    x = tf.add(x, input_tensor)
    x = tf.nn.relu(x, name='res'+str(stage)+block+'_out') 
    
    return x


def ResNet(input_image, norm_type, train_flag, stage5=False):
    """
    ResNet34的整个架构,输入图片,输出最后一层的数据(还没有进行softmax的值)
    """
    # Stage 1
    with tf.name_scope('stage1'):
        x = input_image
        w = weight_variable([7, 7, 3, 64], name='weight_1')
        b = bias_variable([64], name='bias_1')

        x = tf.nn.conv2d(x, w, strides=[1, 2, 2, 1], padding='SAME', name='conv_1') + b    # 32*32*3*64
        x = norm(x, scope='bn_conv1', norm_type=norm_type, is_training=train_flag)         # 32*32*3*64
        # padding = tf.constant([[0, 0], [0, 0], [0, 0], [0, 0]])
        C1 = x = maxpooling(x, [1, 3, 3, 1], [1, 2, 2, 1], name='stage1')                   # 16*16*3*64

    # Stage 2
    with tf.name_scope('stage2'):
        x = identity_block(x, 3, [64, 64], stage=2, block='a', norm_type=norm_type, train_flag=train_flag)           # 16*16*3*64
        x = identity_block(x, 3, [64, 64], stage=2, block='b', norm_type=norm_type, train_flag=train_flag)           # 16*16*3*64
        C2 = x = identity_block(x, 3, [64, 64], stage=2, block='c', norm_type=norm_type, train_flag=train_flag)      # 16*16*3*64

    # Stage 3
    with tf.name_scope('stage3'):
        x = conv_block(x, 3, [128, 128], stage=3, block='a', norm_type=norm_type, train_flag=train_flag, stride2=True)
        x = identity_block(x, 3, [128, 128], stage=3, block='b', norm_type=norm_type, train_flag=train_flag)
        x = identity_block(x, 3, [128, 128], stage=3, block='c', norm_type=norm_type, train_flag=train_flag)
        C3 = x = identity_block(x, 3, [128, 128], stage=3, block='d', norm_type=norm_type, train_flag=train_flag)
        
    # Stage 4
    with tf.name_scope('stage4'):
        x = conv_block(x, 3, [256, 256], stage=4, block='a', norm_type=norm_type, train_flag=train_flag, stride2=True)
        for i in range(5):
            x = identity_block(x, 3, [256, 256], stage=4, block=chr(98+i), norm_type=norm_type, train_flag=train_flag)
        C4 = x

    if stage5:
        x = conv_block(x, 3, [512, 512], stage=5, block='a', train_flag=train_flag, norm_type=norm_type, stride2=True)
        x = identity_block(x, 3, [512, 512], stage=5, block='b', norm_type=norm_type, train_flag=train_flag)
        C5 = x = identity_block(x, 3, [512, 512], stage=5, block='c', norm_type=norm_type, train_flag=train_flag)
        output = avg_pool(C5,1)
        # output=tf.layers.dropout(output,rate=0.5, training=train_flag)  #加入dropout
        # fc= tf.layers.Dense(10)
        w = weight_variable([512, 10], name='fc_weight')
        b = bias_variable([10], name='fc_bias')
        output = tf.reshape(output, [-1, 512], name='fc_1')
        output = tf.matmul(output, w, name='logits') + b

    else:
        C5 = None
        output=avg_pool(C4,2)
        output=tf.layers.flatten(output)
        output = tf.layers.dense(output, 10)

    return [C1, C2, C3, C4, C5, output]

